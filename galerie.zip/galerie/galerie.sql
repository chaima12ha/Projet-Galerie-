-- Adminer 4.8.1 MySQL 8.0.33-0ubuntu0.22.04.2 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id_admin` int NOT NULL AUTO_INCREMENT,
  `nom_ad` varchar(20) NOT NULL,
  `email_ad` varchar(50) DEFAULT NULL,
  `photo_ad` varchar(50) DEFAULT NULL,
  `photo_cov_ad` varchar(50) DEFAULT NULL,
  `login` varchar(20) NOT NULL,
  `mot_passe` varchar(20) NOT NULL,
  PRIMARY KEY (`id_admin`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

INSERT INTO `admin` (`id_admin`, `nom_ad`, `email_ad`, `photo_ad`, `photo_cov_ad`, `login`, `mot_passe`) VALUES
(1,	'chaima',	'chaima@gmail.com',	NULL,	NULL,	'chaima',	'chaima'),
(2,	'MHBM',	'mhbm@gmail.com',	NULL,	NULL,	'mhbm',	'mhbm');

DROP TABLE IF EXISTS `album`;
CREATE TABLE `album` (
  `id_album` int NOT NULL AUTO_INCREMENT,
  `id_util` int DEFAULT NULL,
  `nom_album` varchar(50) NOT NULL,
  `date_album` date DEFAULT NULL,
  `des_album` varchar(100) DEFAULT NULL,
  `tag_album` varchar(20) NOT NULL,
  `etat_album` tinyint(1) DEFAULT NULL,
  `photo_album` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_album`),
  KEY `f2` (`id_util`),
  CONSTRAINT `f2` FOREIGN KEY (`id_util`) REFERENCES `utilisateur` (`id_util`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

INSERT INTO `album` (`id_album`, `id_util`, `nom_album`, `date_album`, `des_album`, `tag_album`, `etat_album`, `photo_album`) VALUES
(18,	17,	'test',	'2023-05-29',	'test',	'test',	0,	NULL);

DROP TABLE IF EXISTS `corbeille`;
CREATE TABLE `corbeille` (
  `id_supp` int NOT NULL AUTO_INCREMENT,
  `id_photo` int NOT NULL DEFAULT '0',
  `id_album` int DEFAULT NULL,
  `nom_photo` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `date_photo` date DEFAULT NULL,
  `des_photo` varchar(100) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci DEFAULT NULL,
  `tag_photo` varchar(20) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `etat_photo` tinyint(1) NOT NULL,
  `photo` varchar(50) CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `stock_photo` int DEFAULT NULL,
  PRIMARY KEY (`id_supp`),
  KEY `id_album` (`id_album`),
  CONSTRAINT `corbeille_ibfk_1` FOREIGN KEY (`id_album`) REFERENCES `album` (`id_album`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


DROP TABLE IF EXISTS `favoris`;
CREATE TABLE `favoris` (
  `id_favoris` int NOT NULL AUTO_INCREMENT,
  `id_util` int DEFAULT NULL,
  `id_photo` int DEFAULT NULL,
  PRIMARY KEY (`id_favoris`),
  KEY `f4` (`id_photo`),
  KEY `f5` (`id_util`),
  CONSTRAINT `f4` FOREIGN KEY (`id_photo`) REFERENCES `photo` (`id_photo`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `f5` FOREIGN KEY (`id_util`) REFERENCES `utilisateur` (`id_util`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


DROP TABLE IF EXISTS `photo`;
CREATE TABLE `photo` (
  `id_photo` int NOT NULL AUTO_INCREMENT,
  `id_album` int DEFAULT NULL,
  `nom_photo` varchar(20) NOT NULL,
  `date_photo` date DEFAULT NULL,
  `des_photo` varchar(100) DEFAULT NULL,
  `tag_photo` varchar(20) NOT NULL,
  `etat_photo` tinyint(1) NOT NULL,
  `photo` varchar(50) NOT NULL,
  `stock_photo` int DEFAULT NULL,
  PRIMARY KEY (`id_photo`),
  KEY `f3` (`id_album`),
  CONSTRAINT `f3` FOREIGN KEY (`id_album`) REFERENCES `album` (`id_album`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

INSERT INTO `photo` (`id_photo`, `id_album`, `nom_photo`, `date_photo`, `des_photo`, `tag_photo`, `etat_photo`, `photo`, `stock_photo`) VALUES
(65,	18,	'test111',	'2023-05-29',	'test',	'test',	1,	'src/source/photo/64746c28ae89f5.26847488.jpeg',	8125),
(66,	18,	'test11',	'2023-05-29',	'test',	'test',	1,	'src/source/photo/64746c4e3f45e3.05605674.jpeg',	8125);

DROP TABLE IF EXISTS `rapport`;
CREATE TABLE `rapport` (
  `id_rapport` int NOT NULL AUTO_INCREMENT,
  `id_util1` int DEFAULT NULL,
  `id_util2` int DEFAULT NULL,
  `id_photo` int DEFAULT NULL,
  `sujet` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_rapport`),
  KEY `q1` (`id_util1`),
  KEY `q2` (`id_util2`),
  KEY `q3` (`id_photo`),
  CONSTRAINT `q1` FOREIGN KEY (`id_util1`) REFERENCES `utilisateur` (`id_util`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `q2` FOREIGN KEY (`id_util2`) REFERENCES `utilisateur` (`id_util`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `q3` FOREIGN KEY (`id_photo`) REFERENCES `photo` (`id_photo`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


DROP TABLE IF EXISTS `utilisateur`;
CREATE TABLE `utilisateur` (
  `id_util` int NOT NULL AUTO_INCREMENT,
  `id_admin` int NOT NULL,
  `login` varchar(20) NOT NULL,
  `nom_util` varchar(20) NOT NULL,
  `email_util` varchar(50) DEFAULT NULL,
  `mot_passe` varchar(50) NOT NULL,
  `image_cov` varchar(255) DEFAULT NULL,
  `image_prof` varchar(255) DEFAULT NULL,
  `stock_util` int DEFAULT NULL,
  `etat` varchar(15) NOT NULL,
  `tel` varchar(15) DEFAULT NULL,
  `sexe` varchar(15) DEFAULT NULL,
  `date_n` date DEFAULT NULL,
  PRIMARY KEY (`id_util`),
  KEY `utilisateur_ibfk_1` (`id_admin`),
  CONSTRAINT `utilisateur_ibfk_1` FOREIGN KEY (`id_admin`) REFERENCES `admin` (`id_admin`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

INSERT INTO `utilisateur` (`id_util`, `id_admin`, `login`, `nom_util`, `email_util`, `mot_passe`, `image_cov`, `image_prof`, `stock_util`, `etat`, `tel`, `sexe`, `date_n`) VALUES
(17,	1,	'test12345',	'test',	'test@test.tn',	'test12345',	NULL,	NULL,	NULL,	'ACTIVE',	NULL,	NULL,	NULL),
(18,	1,	'12345678',	'chaima',	'chaima@gmail.com',	'chaima12',	NULL,	NULL,	NULL,	'ACTIVE',	NULL,	NULL,	NULL);

DROP TABLE IF EXISTS `vote`;
CREATE TABLE `vote` (
  `id_vote` int NOT NULL AUTO_INCREMENT,
  `id_util` int DEFAULT NULL,
  `id_photo` int DEFAULT NULL,
  `vote` int NOT NULL,
  PRIMARY KEY (`id_vote`),
  KEY `f6` (`id_photo`),
  KEY `f7` (`id_util`),
  CONSTRAINT `f6` FOREIGN KEY (`id_photo`) REFERENCES `photo` (`id_photo`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `f7` FOREIGN KEY (`id_util`) REFERENCES `utilisateur` (`id_util`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;


-- 2023-12-16 08:37:20

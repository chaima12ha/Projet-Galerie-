<?php
session_start();
if (!isset($_SESSION['login'])) {
  header("location:index.php?msg=1");
  exit(); // Ajout de l'instruction exit pour arrêter l'exécution du script après la redirection
} else {
  ini_set("display_errors", "1");
  error_reporting(E_ALL);
  require_once("config.php");
}
?>
<!DOCTYPE html>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="src/style/sidebar.css">

</head>
<style>
  body{
    background-color: #eee;
  }
</style>
<body>

  <div class="sidebar">
    <ul>
      <li>
        <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; 
        <?php
          ini_set("display_errors", "1");
          error_reporting(E_ALL);
          require_once("config.php");
              try { 
                  $conn = new PDO($dsn, $user, $pw);
                  $login=$_SESSION['login'];
                  $requete =  "SELECT *  from utilisateur U JOIN admin A on (U.id_admin = A.id_admin)  where( U.login='$login') or ( A.login='$login' )";
                  $resultat = $conn->query($requete); 
                
                  if ($resultat->rowCount()== 0) {
                      header("location:index.php?msg=0");           
                  } else {
                    $row = $resultat->fetch();
                    if($login != 'chaima'){
                          echo( $row['nom_util']);
                    }
                    else if ($login == 'chaima'){
                        echo( $row['nom_ad']);
                      }

                      
                  }
              } catch(PDOExeption $e) {
                  die($e->getMessage());
              }
        ?>
      </span>
        <div id="mySidenav" class="sidenav">
          <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
          <a href="logout.php" target="index.php">deconnecter</a>
          <?php 
          if($login != 'mhbm'){
            ?>
            <a href="profiel.php?action=post"   target="principal">Profiel</a>
            <a href="album.php" target="principal">mes albums</a>
            <a href="mes_photo.php" target="principal">mes photos</a>
            <?php
          }
          ?>
          <div class="image">
            <img src="src/source/image/1.png " alt="image">
          </div>
        </div>
      </li>
      <?php 
      if($login != 'mhbm'){
      ?>
      <span class="titre"> Generalisation</span>
      <li><a href="Galerie.php" target="principal">Explorer photos</a></li>    
      <li><a href="form_album.php" target="principal">ajouter album</a></li>
      <li><a href="form_photo.php" target="principal">Ajouter photo</a></li>
       <span class="titre"> bibliotheque</span>
      <li><a href="favori.php" target="principal">Favorite</a></li>
      <li><a href="corbeille.php" target="principal">Corbeille</a></li>
      <span class="titre">Service</span>
      <li><a href="Contact.php" target="principal">Contact</a></li>
      <span class="titre">Stockage</span>
      <?php
        }else{
       ?>
      <li><a href="admin.php" target="principal">Utilisateur</a></li>    
      <li><a href="rapport.php" target="principal">Rapport</a></li>       
       <?php
        }
      ?>

    


    </ul>
  </div>

  <script>
    function openNav() {
      document.getElementById("mySidenav").style.width = "250px";
    }

    function closeNav() {
      document.getElementById("mySidenav").style.width = "0";
    }
  </script>

</body>

</html>
function openNav(x) {
    let mySidebarx="mySidebar"+x;
    let mainx="main"+x;
    this.document.getElementById(mySidebarx).style.width = "340px";
    this.document.getElementById(mainx).style.marginLeft = "250px";
  }
  
  function closeNav(x) {
    let mySidebarx="mySidebar"+x;
    let mainx="main"+x;
    document.getElementById("mySidebar"+x).style.width = "0";
    document.getElementById("main"+x).style.marginLeft= "0";
  }
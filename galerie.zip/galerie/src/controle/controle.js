function verifch(ch) {
    let ch2 = "abcdefghijklmnopqrstuvwxyz";
    let ok = true;
    for (let i = 0; i < ch.length; i++) {
      if (ch2.indexOf(ch.charAt(i).toLowerCase()) < 0) {
        ok = false;
        break; // Ajout de l'instruction "break" pour sortir de la boucle dès qu'un caractère non valide est trouvé
      }
    }
    return ok;
  }
  
  function verifi() {

    let login = document.getElementById("login").value;
    let nom = document.getElementById("Nom").value;
    let email = document.getElementById("Email").value;
    let motpasse = document.getElementById("Motpasse").value;
    let cmotpasse = document.getElementById("Cmotpasse").value;
    if (
        login === "" ||
        login.length < 3 ||
        login.length > 15 
    ) {
      document.getElementById("login").style.border = "2px solid red";
    } else {
      document.getElementById("login").style.border = "2px solid green";
    }
    if (
      nom === "" ||
      nom.length < 3 ||
      nom.length > 15 ||
      nom.indexOf(" ") > -1 ||
      verifch(nom) === false
    ) {
      document.getElementById("Nom").style.border = "2px solid red";
    } else {
      document.getElementById("Nom").style.border = "2px solid green";
    }
  
    if (
      email.length < 5 ||
      email.indexOf("@") < 0 ||
      email.indexOf(".", email.indexOf("@")) < 0
    ) {
      document.getElementById("Email").style.border = "2px solid red";
    } else {
      document.getElementById("Email").style.border = "2px solid green";
    }
    if (motpasse === "" || motpasse.length < 3 || motpasse.length > 15) {
      document.getElementById("Motpasse").style.border = "2px solid red";
    } else {
      document.getElementById("Motpasse").style.border = "2px solid green";
    }
    if (motpasse === "" || cmotpasse !== motpasse) {
      document.getElementById("Cmotpasse").style.border = "2px solid red";
    } else {
      document.getElementById("Cmotpasse").style.border = "2px solid green";
    }
  }
  
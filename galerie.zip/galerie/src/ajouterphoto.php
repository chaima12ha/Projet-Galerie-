<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
<form method="post" action="ajouter_photo.php" enctype="multipart/form-data">
    <input type="hidden" name="MAX_FILE_SIZE" value="1000000"><br>
    <label for="nom_photo">Nom de la photo:</label>
    <input type="text" name="nom_photo" id="nom_photo">
    <label for="date_photo">Date de la photo:</label>
    <input type="date" name="date_photo" id="date_photo">
    <label for="des_photo">Description de la photo:</label>
    <textarea name="des_photo" id="des_photo"></textarea>
    <label for="tag_photo">Tag de la photo:</label>
    <input type="text" name="tag_photo" id="tag_photo">
    <label for="photo">Photo:</label>
    <input type="file" name="photo" id="photo">
    <label for="id_album">Album:</label>
    <select name="id_album" id="id_album">
        <?php
            // Connexion à la base de données
            $bdd = new PDO('mysql:host=localhost;dbname=galerie', 'chaima', 'chaima');
            // Requête pour récupérer les albums
            $requete = $bdd->query("SELECT id_album, nom_album FROM album");
            // Boucle pour afficher les options
            while ($album = $requete->fetch()) {
                echo '<option value="'.$album['id_album'].'">'.$album['nom_album'].'</option>';
            }
            // Fermeture de la requête
            $requete->closeCursor();
        ?>
    </select>
    <input type="submit" value="Ajouter la photo">
</form>

</body>
</html>
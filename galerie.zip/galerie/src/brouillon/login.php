<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="verif.php" method="post">
        Login: <input type="text" name="login" id=""><br>
        Mot de passe : <input type="password" name="pw" id="">
        <br> <input type="submit" value="ok">
    </form>
    <h3> <a href="inscription.php"> Inscription</a></h3>
    <hr>
<?php
if (isset($_GET['msg'])) {
    $msg=$_GET['msg'];
    if ($msg==0) {
        echo "Login ou mot de passe incorrect....";
    }
    if ($msg==1) {
        echo "Vous devez vous connecter d'abord";
    }
    if ($msg==2) {
        echo "Vous avez ete deconnecte...";    }    
}
?>
</body>
</html>
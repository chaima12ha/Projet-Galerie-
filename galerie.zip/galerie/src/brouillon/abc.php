<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  // Vérifier si le champ de l'image n'est pas vide
  if (!empty($_FILES['image']['name'])) {
    // Récupérer les informations du fichier
    $file_name = $_FILES['image']['name'];
    $file_tmp = $_FILES['image']['tmp_name'];
    $file_size = $_FILES['image']['size'];
    $file_error = $_FILES['image']['error'];

    // Vérifier si le fichier est une image
    $file_type = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
    $allowed_types = array("jpg", "jpeg", "png", "gif");
    if (!in_array($file_type, $allowed_types)) {
      echo "Seules les images JPG, JPEG, PNG et GIF sont autorisées.";
      exit();
    }

    // Vérifier si le fichier n'a pas d'erreurs
    if ($file_error !== 0) {
      echo "Il y a eu une erreur lors du téléchargement de l'image.";
      exit();
    }

    // Vérifier la taille du fichier
    if ($file_size > 2097152) {
      echo "La taille de l'image doit être inférieure à 2 Mo.";
      exit();
    }

    // Générer un nom de fichier unique
    $file_name_new = uniqid('', true) . '.' . $file_type;

    // Enregistrer le fichier dans le répertoire "image"
    $file_path = 'image/' . $file_name_new;
    if (!move_uploaded_file($file_tmp, $file_path)) {
      echo "Il y a eu une erreur lors de l'enregistrement de l'image.";
      exit();
    }

    // Enregistrer l'URL de l'image dans la base de données
    $host = "localhost";
    $user = "username";
    $password = "password";
    $dbname = "nom_de_la_base_de_donnees";

    $conn = mysqli_connect($host, $user, $password, $dbname);
    if (!$conn) {
      die("Connexion échouée : " . mysqli_connect_error());
    }

    $nom_photo = $file_name_new;
    $tag_photo = "tag_de_l'image";
    $etat_photo = 1; // 1 pour actif, 0 pour inactif

    $sql = "INSERT INTO photo (id_album, nom_photo, tag_photo, etat_photo, photo) VALUES (NULL, '$nom_photo', '$tag_photo', $etat_photo, '$file_path')";

    if (mysqli_query($conn, $sql)) {
      echo "L'image a été téléchargée avec succès.";
    } else {
      echo "Erreur lors de l'enregistrement de l'image : " . mysqli_error($conn);
    }

    mysqli_close($conn);
  } else {
    echo "Veuillez sélectionner une image à télécharger.";
  }
}
?>

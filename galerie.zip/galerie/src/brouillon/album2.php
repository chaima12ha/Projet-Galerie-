<?php
  session_start();
  if(!isset($_SESSION['login']))
  {
    header("location:index.php?msg=1");
  }
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Galerie</title>
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
      integrity="sha512-34e/X5vzG8W5+ml4D4dtYmttlUnSmvSNpgWwUuOnr1C7+9eOYMxKmBfFWLAgIYVgOuTYvQHw7STI74bQ2Ngy9g=="
      crossorigin="anonymous"
      referrerpolicy="no-referrer"
    />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"
    />
    <link rel="stylesheet" href="src/style/style_box_image.css" />
  </head>
  <style>
  </style>
  <body>
<?php
  ini_set("display_errors", "1");
  error_reporting(E_ALL);
  require_once("config.php");
      try { 
          $conn = new PDO($dsn, $user, $pw);
          $login=$_SESSION['login'];
          $requete = "select * from album natural join utilisateur where login='$login'; ";

          $resultat = $conn->query($requete); // il contient les donnees retournees par le sgbd
        
          if ($resultat->rowCount()== 0) {
              header("location:index.php?msg=0");           
          } else {
           $x=1; 
            while ($row = $resultat->fetch()) {               
                echo '
                <div class="photo-box">
                    <img src="src/source/image/album'.$x.'.jpg" alt="Photo"/>
                    <div class="buttons">
                        <button>
                            <span>ok</span>
                        </button>
                    </div>
                    <div class="user-info">
                        <span class="username">'.$row['nom_album'].'</span>
                    </div>
                </div>
                ';
                $x=$x+1;
            }
}
  } catch(PDOExeption $e) {
    die($e->getMessage());
}
    ?>
  </body>
  <script src="src/controle/modal.js"></script>
</html>

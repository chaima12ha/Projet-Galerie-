<?php
//session_start();
if (!isset($_SESSION['login'])) {
  header("location:index.php?msg=1");
  exit();
} else {
  $login = $_SESSION['login'];
  $conn = new mysqli('localhost', 'mhbm', 'mhbm', 'galerie');
  if ($conn->connect_error) {
    die("Erreur de connexion à la base de données: " . $conn->connect_error);
  }
  $result = $conn->query("SELECT id_album, nom_album FROM album NATURAL JOIN utilisateur WHERE login='$login'");
  if ($result->num_rows == 0) {
    header("location:form_album.php");
    exit();
  }
}

?>

<!DOCTYPE html>
<html>

<head>
  <title>Ajouter photo</title>
  <link rel="stylesheet" href="style.css">
  <link rel="stylesheet" href="style_input.css">
  <link rel="stylesheet" type="text/css" href="src/style/style_title.css">
</head>

<body>
  <div class="page">
    <h2 class="main-title">AJOUTER PHOTO</h2>
    <hr width="90%" color="#2196f3">
    <div class="container">
      <form action="ajouter_photo.php" method="post" enctype="multipart/form-data">
        <label for="nom_photo">Nom de la photo:</label>
        <input type="text" id="nom_photo" name="nom_photo" required>
        <label for="des_photo">Description de la photo:</label>
        <input type="text" id="des_photo" name="des_photo" required>
        <label for="tag_photo">Tag de la photo:</label>
        <input type="text" id="tag_photo" name="tag_photo" required>
        <label for="album">Album:</label>
        <select id="album" name="id_album" required>
          <?php
          while ($row = $result->fetch_assoc()) {
            echo '<option value="' . $row['id_album'] . '">' . $row['nom_album'] . '</option>';
          }
          $result->close();
          $conn->close();
          ?>
        </select>
        <label for="etat_photo">Etat de la photo:</label>
        <select name="etat_photo" id="etats">
          <option value="1">Public</option>
          <option value="0">Privé</option>
        </select>
        <label for="photo">Sélectionnez une photo:</label>
        <input type="file" id="photo" name="photo" accept="image/*" required>
        <input id="submit" name="submit" type="submit" value="Ajouter">
      </form>
    </div>
  </div>
</body>

</html>

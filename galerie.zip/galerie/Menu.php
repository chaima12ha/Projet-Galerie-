<?php
  session_start();
  if(!isset($_SESSION['login']))
  {
    header("location:index.php?msg=1");
  }
  else{
    ini_set("display_errors", "1");
    error_reporting(E_ALL);
    $login = $_SESSION['login'];
    require_once("config.php");
        try { 
            $conn = new PDO($dsn, $user, $pw);
            $login=$_SESSION['login'];

            $requete = "SELECT *  from utilisateur U JOIN admin A on (U.id_admin = A.id_admin)  where( U.login='$login') or ( A.login='$login' )";
            $resultat = $conn->query($requete); 
          
            if ($resultat->rowCount()== 0) {
                echo "erreure";           
            } else {
              $row = $resultat->fetch();
            ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="src/style/style_menu.css">
    <title>Document</title>
</head>

<body>
       <!-- Header -->
   <header class="header">
    <div class="container">
    <a class="logo"><img src="src/source/image/royale.png" alt=""> <span> Galerie </span></a>
    <?php if($login != "chaima") { ?>
        <div class="search-bar">
            <form action="Galerie.php?action=recherche" method="post" target="principal">
              <input type="text" placeholder="Rechercher..." name="recherche">
              <button type="submit">Rechercher</button>
            </form>
          </div>
        <ul class="main_nav">
            <li><a href="form_photo.php" target="principal"> <button class="buttonajoute">Ajouter photo</button></a></li>
            <li><a href="Galerie.php" target="principal"><img src="src/source/image/accueil.png" class="imagemenu"></a></li>
            <li><a href="Contact.php" target="principal"><img src="src/source/image/settings.png" class="imagemenu"></a></li>
            <li>
              <a href="profiel.php" target="principal">
                <img class="imagemenu" src="<?php
                  if($login != 'chaima') {
                    if(isset($row['image_prof'])) {
                      echo $row['image_prof'];
                    } else {
                      echo "src/source/image/utilisateur.png"; 
                    }
                  } else if ($login == 'chaima') {
                    if(isset($row['photo_ad'])) {
                      echo $row['photo_ad'];
                    } else {
                      echo 'src/source/image/utilisateur.png';
                    }
                  }
                ?>" >
              </a>
            </li>

        </ul>
      <?php } ?>
    </div>

    <?php
      }} catch(PDOExeption $e) {
        die($e->getMessage());
      }
    }
    ?>
   </header>
   <!-- Fin Header -->
</body>
</html>
<?php
session_start();
if (!isset($_SESSION['login'])) {
    header("location:index.php?msg=1");
    exit; // Terminate the script after redirecting
}else{
  $login = $_SESSION['login'];

  ini_set("display_errors", "1");
  error_reporting(E_ALL);
  require_once("config.php");
  $conn = new PDO($dsn, $user, $pw);
  if (isset($_GET['action'])){
   
    $action = $_GET['action'];
    
    if ($action == 'rapport') {
        $requser = "SELECT id_util FROM utilisateur WHERE login='$login'";
        $resuser = $conn->query($requser);
        $rowuser = $resuser->fetch();
        $id_util = $rowuser['id_util'];
        $sujet = mysqli_real_escape_string($conn, $_POST['sujet']);
        echo $sujet;
        $reqadd = "INSERT INTO rapport (id_util1, sujet) VALUES ($id_util, '$sujet')";
        $resadd = $conn->query($reqadd);
    }
    
  }
}

?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="src/style/style_title.css">
    <style>
        body {
            font-family: Arial, Helvetica, sans-serif;
        }

        * {
            box-sizing: border-box;
        }

        /* Style inputs */
        input[type=text],
        select,
        textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            margin-top: 6px;
            margin-bottom: 16px;
            resize: vertical;
        }
        img{
          margin-top:0;
        }
        input[type=submit] {
            background-color: lawngreen;
            color: #000;
            padding: 12px 20px;
            border: none;
            cursor: pointer;
            font-style: italic;
            font-weight: 600;
        }

        input[type=submit]:hover {
            background-color: #2196f3;
        }

        .column {
            float: left;
            width: 50%;
            margin-top: 6px;
            padding: 20px;
        }

        .row:after {
            content: "";
            display: table;
            clear: both;
        }

        @media screen and (max-width: 600px) {
            .column,
            input[type=submit] {
                width: 100%;
                margin-top: 0;
            }
        }

        form {
            margin-top: 30px;
        }
    </style>
</head>

<body>
    <div class="page">
        <h2 class="main-title">Contact admin</h2>
        <hr width="90%" color="#2196f3">
        <div class="container">
            <div style="text-align:center">
                <h1>Passez prendre une tasse de café ou laissez-nous un message :</h1>
            </div>
            <div class="row">
                <div class="column">
                    <img src="src/source/image/1.png" style="width: 450px" alt="galerie Image">
                </div>
                <div class="column">
                    <form action="Contact.php?action=rapport" method="post">
                        <label for="subject"><h4>Sujet</h4></label>
                        <textarea id="subject" name="sujet" placeholder="Écris quelque chose...." style="height:170px" required></textarea>
                        <input type="submit" value="Submit">
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

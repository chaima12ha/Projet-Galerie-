<?php
  session_start();
  if(!isset($_SESSION['login']))
  {
    header("location:index.php?msg=1");
  }
  else{
    $login =$_SESSION['login'];
     ini_set("display_errors", "1");
      error_reporting(E_ALL);
      require_once("config.php");
      $conn = new PDO($dsn, $user, $pw);

      $requser = "select * from utilisateur  where login= '$login'";
      $resuser= $conn->query($requser);
      $rowuser = $resuser->fetch();
      $util1 = $rowuser['id_util'];
      $login1 =$rowuser['login'];
  }

  if (isset($_GET['action'])){
   
    $action = $_GET['action'];
    
    if($action == 'favori' ){
      $util=(int)$_GET['id_util'];
      //echo (gettype($util)."   util".$util."<br>");

      $photo=(int)$_GET['id_photo'];
      //echo (gettype($photo)."  photo " .$photo);

      $reqs = "SELECT * FROM `favoris` WHERE (`id_util`=$util) AND (`id_photo`=$photo)  ";
      $ress= $conn->query($reqs);
     
      if ($ress->rowCount() > 0) {
        $reqd="delete from favoris where id_photo= $photo and id_util =$util";
        $resd = $conn->query($reqd);
            header("location:favori.php");
      }
      else{
            $reqi = "INSERT INTO `favoris` (`id_util`, `id_photo`) VALUES ( $util, $photo)";
            $resi = $conn->query($reqi);
                header("location:favori.php");
      }
        // action = farori
      }
      if($action == 'voter' ){

        $vote =$_POST['vote'];
        //echo $vote;
        $photo=(int)$_GET['id_photo'];

        $reqs = "SELECT * FROM `vote` WHERE (`id_util`=$util1) AND (`id_photo`=$photo)  ";
        $ress= $conn->query($reqs);
        
        if ($ress->rowCount() > 0) {
          $requ="update vote set vote = $vote where id_photo= $photo and id_util =$util1";
          $resu = $conn->query($requ);
            //echo("update ");
            header("location:album.php");
        }else{
          $reqi="insert into vote(id_util,id_photo,vote) values($util1,$photo,$vote)";
          $resi = $conn->query($reqi);
          //echo("insertion");
          header("location:album.php");

        }      
          // action = vote
      }
      if($action == 'supprimer' ){
        $photo=(int)$_GET['id_photo'];

        $req_photo = "SELECT * FROM `photo` WHERE   (`id_photo`=$photo)  ";
        $res_photo= $conn->query($req_photo);
        $row_photo = $res_photo->fetch();

        $id_album = $row_photo['id_album'];
        $id_photo = $row_photo['id_photo'];
        $nom_photo = $row_photo['nom_photo'];
        $des_photo = $row_photo['des_photo'];
        $tag_photo = $row_photo['tag_photo'];
        $etat_photo = $row_photo['etat_photo'];
        $date_photo = $row_photo['date_photo'];
        $file_path = $row_photo['photo'];
        $file_size = $row_photo['stock_photo'];

        if ($res_photo->rowCount() > 0) {

          $req_corbeille = "INSERT INTO corbeille (id_photo, id_album, nom_photo, date_photo, des_photo, tag_photo, etat_photo, photo,stock_photo)
          VALUES ( '$id_photo', '$id_album', '$nom_photo', '$date_photo', '$des_photo', '$tag_photo', '$etat_photo', '$file_path', $file_size)";
          $res_corbeille = $conn->query($req_corbeille);
          if($res_corbeille){
            //echo ("insertion corbeille <br>");
          }

          $req_delete = "DELETE  FROM photo  WHERE   `id_photo`= $photo ";
          $res_delete = $conn->query($req_delete );
          if($res_delete){
            //echo("delete terminer <br>");
            header("location:corbeille.php");
          }


        }
          // action = spprimer

      }

      if($action == 'photo_profi' ){
        $photo=(int)$_GET['id_photo'];
        $album=(int)$_GET['id_album'];


        $req_photo = "SELECT photo FROM `photo` WHERE `id_photo`=$photo  ";
        $res_photo= $conn->query($req_photo);
        $row_photo = $res_photo->fetch();
        $photo = $row_photo['photo'];
        $req_update="UPDATE album
        SET photo_album = '$photo'
        WHERE id_album = $album";
        $res_update= $conn->query($req_update);
        $row_update = $res_update->fetch();
        header("location:album.php");
      }
      if ($action == 'partager') {
        $photo = (int)$_GET['id_photo'];
        $eta = (int)$_GET['etat'];
    
        if ($eta == 0) {
            $etat = 1;
        } else if ($eta == 1) {
            $etat = 0;
        }
    
        $req_update = "UPDATE photo SET etat_photo = '$etat' WHERE id_photo = $photo";
        //echo $req_update;
        $res_update = $conn->query($req_update);
        // Supprimez la ligne suivante car il n'est pas nécessaire de récupérer les résultats de la requête UPDATE
        // $row_update = $res_update->fetch();
        header("location:mes_photo.php");
    }
      

  }


?>
<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Galerie</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
    integrity="sha512-34e/X5vzG8W5+ml4D4dtYmttlUnSmvSNpgWwUuOnr1C7+9eOYMxKmBfFWLAgIYVgOuTYvQHw7STI74bQ2Ngy9g=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
  <link rel="stylesheet" href="src/style/style_box_image.css" />
  <link rel="stylesheet" href="src/style/stylestar.css" />
  <link rel="stylesheet" href="src/style/style_modal.css" />
  <link rel="stylesheet" href="src/style/stylestar.css" />
  <link rel="stylesheet" href="src/style/style_auti.css">
  <link rel="stylesheet" href="src/style/style_title.css">

  
</head>


<body>
    <?php
            if (isset($_GET['msg'])){
                //if ($action == 'album'){
                    $nom_album= $_GET['nom_album'];
                }
    ?>
  <div class="page">
  <h2 class="main-title">  <?php echo ($nom_album) ?></h2>
  <hr width="90%" color="#2196f3">
  <div class="container">
    <div class="box">
      <?php
          try { 
            if (isset($_GET['msg'])){
            //if ($action == 'album'){
                $id_album= $_GET['id_album'];
            }
                
            //}
              $requete = "select * from photo F join album A on(F.id_album =A.id_album )join utilisateur U
              on (A.id_util =U.id_util ) where F.id_album =$id_album order by date_photo desc";

              $resultat = $conn->query($requete);

            
              if ($resultat->rowCount()== 0) {
                echo ("cet album est vide! <br> remplir vite cet album ");
              } else {
              $x=0; 
                while ($row = $resultat->fetch()) {
              ?>
      <div class="container2">
      <div class="photo-box">
        <img src="<?php echo( $row['photo']);?>" alt="Photo" />
        <div class="buttons">

          <?php
              // vote selection
              $photo_vote = $row['id_photo'];
              $req_vote = "select avg(vote) as 'v' from vote  where  id_photo=$photo_vote ;";
              $res_vote= $conn->query($req_vote);
              $row_vote = $res_vote->fetch();
              $vote = $row_vote['v'];
              if($vote >0){
              $vote =number_format($vote, 1, ',');
              echo ('<button><span class="fa fa-star checked"> '.$vote.' </span></button>');
              }
              ?>




          <button class="favorite"><i class="fa fa-heart"></i><a
              href="?action=favori&id_photo=<?php echo($row['id_photo']);?>&id_util=<?php echo($rowuser['id_util']) ?>">jaime</a></button>

          <button class="vote" id="<?php echo("myBtn".$x); ?>" onclick="modal(
            <?php echo($x); ?>);">
            <i class="fa fa-thumbs-up"></i>voter
          </button>
          <?php echo'<div id="myModal'.$x.'" class="modal">'; ?>
          <div class="modal-content">
            <?php echo'<span class="close close'.$x.'">&times;</span>'; ?>
            <div class="rating">
              <?php echo('
                  <div class="stars stars'.$x.'">
                    <span class="star star'.$x.'" data-rating="1"></span>
                    <span class="star star'.$x.'" data-rating="2"></span>
                    <span class="star star'.$x.'" data-rating="3"></span>
                    <span class="star star'.$x.'" data-rating="4"></span>
                    <span class="star star'.$x.'" data-rating="5"></span>
                  </div>
                  '); ?>
            </div>

            <input type="hidden" name="rating" class="rating-value" id="rating_value<?php echo $x; ?>" />
            <form name="f" action="?action=voter&id_photo=<?php echo $row['id_photo']; ?>&id_util=<?php echo $row['id_util']; ?>" method="post" class="votestyle">
            <input type="text" name="vote" id="vote<?php echo $x; ?>" value="0" readonly>
              <!--<input type="text" name="vote" id="vote<?php //echo $x; ?>" value="0" readonly disabled >-->
              <div class="selected-rating selected_rating<?php echo $x; ?>"></div><br><br>
              <button class="starbuttan" id="starbuttan<?php echo $x; ?>">Voter</button>
            </form>
          </div>
        </div>
      </div>
      <div class="user-info">
        <img src="
        <?php 
          if(isset($row['image_prof'])){
              echo( $row['image_prof']);
            }
          else{
          echo" src/source/image/utilisateur.png"; } ?>
        "alt="User" />
        <span class="username">
          <?php echo($row['nom_util']);?>
        </span>
      </div>
      <div class="menu-info">
        <div id="<?php echo('mySidebar'.$x); ?>" class="sidebar">
          <a href="javascript:void(0)" class="closebtn" onclick="closeNav(<?php echo($x); ?>)">×</a>
          <?php
              $photo = $row['id_photo'];
              $eta =$row['etat_photo'];
              if ($eta ==0){
                $etat="partager aux public"   ;           
              }if($eta ==1){
                $etat="mettre en priver";
               }
              echo('<a href="?action=partager&id_photo='.$photo.'&etat='.$eta.'" >'.$etat.'</a>');
              $photo = $row['id_photo'];
              echo('<a href="?action=supprimer&id_photo='.$photo.'" >supprimer</a>');

            echo('<a href="?action=photo_profi&id_photo='.$photo.'&id_album='.$id_album.'" >defeni comme photo d\'album</a>');

          ?>
        </div>

        <div id=" <?php echo('main'.$x); ?>">
          <button class="openbtn" onclick="openNav(<?php echo($x) ;?>)">☰</button>
        </div>
        <script src="src/controle/controle_auti.js"></script>
      </div>
    </div>
    </div>
    <?php
        $x=$x+1;
      }
    }
      } catch(PDOExeption $e) {
        die($e->getMessage());
    }
    ?>
  </div>
  </div>
</body>
<script src="src/controle/modal.js"></script>

</html>
<?php
  session_start();
  if(!isset($_SESSION['login']))
  {
    header("location:index.php?msg=1");
  }
  else{
    $login =$_SESSION['login'];
     ini_set("display_errors", "1");
      error_reporting(E_ALL);
      require_once("config.php");
      $conn = new PDO($dsn, $user, $pw);

      $requser = "select * from utilisateur  where login= '$login'";
      $resuser= $conn->query($requser);
      $rowuser = $resuser->fetch();
      $util1 = $rowuser['id_util'];
      $login1 =$rowuser['login'];
  }

  if (isset($_GET['action'])){
   
    $action = $_GET['action'];
  
      if($action == 'supprimer' ){

        $id_album=(int)$_GET['id_album'];
        echo $id_album;

        $req_delete = "DELETE  FROM album  WHERE  `id_album`= $id_album";
        $res_delete = $conn->query($req_delete );
        if($res_delete){
          echo("delete terminer <br>");
        }


          // action = spprimer
      }
      

  }


?>
<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Galerie</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
    integrity="sha512-34e/X5vzG8W5+ml4D4dtYmttlUnSmvSNpgWwUuOnr1C7+9eOYMxKmBfFWLAgIYVgOuTYvQHw7STI74bQ2Ngy9g=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
  <link rel="stylesheet" href="src/style/style_box_image.css" />
  <link rel="stylesheet" href="src/style/stylestar.css" />
  <link rel="stylesheet" href="src/style/style_modal.css" />
  <link rel="stylesheet" href="src/style/stylestar.css" />
  <link rel="stylesheet" href="src/style/style_auti.css">
  <link rel="stylesheet" href="src/style/style_title.css">

  
</head>


<body>
  <div class="page">
  <h2 class="main-title"> mes album</h2>
  <hr width="90%" color="#2196f3">
  <div class="container">
    <div class="box">
      <?php
          try { 
              $requete = "select * from album natural join utilisateur where login='$login'";

              $resultat = $conn->query($requete);
            
              if ($resultat->rowCount()== 0) {
                 header("location:Galerie.php?");           
              } else {
              $x=0; 
                while ($row = $resultat->fetch()) {
              ?>
      <div class="container2">
      <div class="photo-box">
        <img src="<?php echo( $row['photo_album']);?>" alt="Photo" />
        <div class="buttons">
          <button><?php echo( $row['nom_album']);?></button>
          <button><a href="photo_album.php?msg=album&id_album=<?php echo ($row['id_album']);?>&nom_album=<?php echo ($row['nom_album']);?>" >voir photo</a></button>


        </div>

      <div class="user-info">
        <img src="
        <?php 
          if(isset($row['image_prof'])){
              echo( $row['image_prof']);
            }
          else{
          echo" src/source/image/utilisateur.png"; } ?>
        "alt="User" />
        <span class="username">
          <?php echo($row['nom_util']);?>
        </span>
      </div>
      <div class="menu-info">
        <div id="<?php echo('mySidebar'.$x); ?>" class="sidebar">
          <a href="javascript:void(0)" class="closebtn" onclick="closeNav(<?php echo($x); ?>)">×</a>
          <?php
          $id_album = $row['id_album'];
          echo('<a href="?action=supprimer&id_album='.$id_album.'" >supprimer album</a>');
          ?>
        </div>

        <div id=" <?php echo('main'.$x); ?>">
          <button class="openbtn" onclick="openNav(<?php echo($x) ;?>)">☰</button>
        </div>
        <script src="src/controle/controle_auti.js"></script>
      </div>
    </div>
    </div>
    <?php
        $x=$x+1;
      }
    }
      } catch(PDOExeption $e) {
        die($e->getMessage());
    }
    ?>
  </div>
  </div>
</body>
<script src="src/controle/modal.js"></script>

</html>
<?php
  session_start();
  if(!isset($_SESSION['login']))
  {
    header("location:index.php?msg=1");
  }
  else {
    $login =$_SESSION['login'];
     ini_set("display_errors", "1");
      error_reporting(E_ALL);
      require_once("config.php");
      $conn = new PDO($dsn, $user, $pw);
  }

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta property="og:type" content="website"/>
    <meta property="image" src="src/source/image/1.png"/>
	<title>Accueil</title>
</head>
<frameset rows="60,*">
	<frame frameborder="0" name="banniere" scrolling="no" noresize target="sommaire" src="Menu.php">
	<frameset cols="230,*">
		<frame frameborder="0" name="sommaire" target="principal" scrolling="no" noresize src="sidebar.php">
		<frame frameborder="0" name="principal" 
		<?php 
		if($login!='chaima'){
			echo('src="Galerie.php"');
		}
		else{
			echo('src="admin.php"');
		}
		?>
		>
	</frameset>
</frameset>
<body>
	
</body>
</html>

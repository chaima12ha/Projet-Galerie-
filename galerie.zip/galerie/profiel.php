<?php
  session_start();
  if(!isset($_SESSION['login']))
  {
    header("location:index.php?msg=1");
  }
  else{
    $login = $_SESSION['login'];

    ini_set("display_errors", "1");
    error_reporting(E_ALL);
    require_once("config.php");
    $conn = new PDO($dsn, $user, $pw);
    $requete = "select * from utilisateur where login='$login'";
    $resultat = $conn->query($requete);
    $row = $resultat->fetch();

    $requete2 = "select * from photo F join album A on(F.id_album =A.id_album ) join utilisateur U
    on (A.id_util =U.id_util ) where login ='$login' order by date_photo desc;
    ";
    $resultat2 = $conn->query($requete2);
  }
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="style_profi.css" />
  <title>Profile</title>
</head>

<body>
  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div id="content" class="content content-full-width">
          <div class="profile">
            <div class="profile-header">
              <div class="profile-header-cover"></div>
              <div class="profile-header-content">
                <div class="profile-header-img">
                  <img src="<?php echo($row['image_prof']);  ?>" alt="" />
                </div>
                <div class="profile-header-info">
                  <h4 class="m-t-10 m-b-5">
                    <?php echo $row['nom_util'];  ?>
                  </h4>
                  <p class="m-b-10">
                    <?php  echo $row['email_util']; ?>
                  </p>
                  <a href="?action=about" class="btn btn-sm btn-info mb-2">Edit Profile</a>
                </div>
              </div>
              <ul class="profile-header-tab nav nav-tabs">
                <li class="nav-item">
                  <a href="profiel.php?action=post"  class="nav-link_">POSTS</a>
                </li>
                <li class="nav-item">
                  <a href="?action=about" class="nav-link_">ABOUT</a>
                </li>
                <li class="nav-item">
                  <a href="?action=photo" class="nav-link_">PHOTOS</a>
                </li>
              </ul>
            </div>
          </div>

      <?php
      if (isset($_GET['action'])){

          $action = $_GET['action'];
    
          if($action == 'post' ){
            
            while ($row2 = $resultat2->fetch()){
            ?>
            <!-- debut pub -->
            <div class="profile-content">
              <div class="tab-content p-0">
                <div class="tab-pane fade active show" id="profile-post">
                  <ul class="timeline">
                    <li>
                      <div class="timeline-time">
                        <span class="date">
                          <?php echo $row2['date_photo'];  ?>
                        </span>
                        <span class="time">
                          <?php echo $row2['nom_album'];  ?>
                        </span>
                      </div>
                      <div class="timeline-icon">
                        <a href="javascript:;">&nbsp;</a>
                      </div>
                      <div class="timeline-body">
                        <div class="timeline-header">
                          <span class="userimage"><img src="<?php echo($row['image_prof']); ?>"
                              alt="" /></span>
                          <span class="username">
                              <?php echo $row['nom_util'];  ?>
                             <small></small></span>
                          <!-- <span class="pull-right text-muted">18 Views</span> -->
                        </div>
                        <div class="timeline-content">
                          <img class="image_pub" src="<?php echo( $row2['photo']);?>" alt="">
                        </div>
                      </div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <!-- fin pub -->
            <?php
            }
            ?>

            <!-- debut pub -->
            <div class="profile-content">
              <div class="tab-content p-0">
                <div class="tab-pane fade active show" id="profile-post">
                  <ul class="timeline">
                    <li>
                      <div class="timeline-body">Loading...</div>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <!-- fin pub -->

          <?php
          }

         if($action == 'about' ){
          ?>
          <div class="page">
            <div class="container">
                  <div class="row">
                        <div class="col-md-12">
               <div class="container">
                  <div class="row">
                     <div class="col-md-12">
                        <div id="content" class="content content-full-width">

                           <!-- begin profile-content -->
                           <div class="profile-content">
                              <!-- begin tab-content -->
                              <div class="tab-content p-0">
               
                                 <!-- begin #profile-about tab -->
                                 <div class="tab-pane fade in active show" id="profile-about">
                                    <!-- begin table -->
                                    <div class="table-responsive">
                                       <table class="table table-profile" >
                                          <thead>
                                             <tr>
                                                <th></th>
                                                <th>
                                                   <h4><?php echo($row['nom_util']) ; ?></small></h4>
                                                </th>
                                             </tr>
                                          </thead>
                                          <tbody>
                                           <tr class="highlight">
                                                <td class="field">LOGIN  </td>
                                                <td><?php echo($row['login']) ; ?></td>
                                             </tr>
                                             <tr class="divider">
                                                <td colspan="2"></td>
                                             </tr>
                                             <tr>
                                                <td class="field">Telephone</td>
                                                <td><i class="fa fa-mobile fa-lg m-r-5"></i> <?php echo($row['tel']) ; ?> <a href="javascript:;" class="m-l-5"></a></td>
                                             </tr>
                                             <tr>
                                                <td class="field">Sexe :</td>
                                                <td><a href="javascript:;"><?php echo($row['sexe']) ; ?></a></td>
                                             </tr>
                                             <tr>
                                                <td class="field">Birthdate</td>
                                                <td><a href="javascript:;"><?php echo($row['date_n']) ; ?></a></td>
                                             </tr>
                                             <tr class="divider">
                                                <td colspan="2"></td>
                                             </tr>
                                             <tr class="highlight">
                                                <td class="field">Chonger</td>
                                                <td>Information</td>
                                             </tr>
                                             <tr class="divider">
                                                <td colspan="2"></td>
                                             </tr>
                                             <tr>
                                                <td class="field">sexe</td>
                                                <td>
                                                   <select class="form-control input-inline input-xs" name="sexe">
                                                      <option value="male">Femme</option>
                                                      <option value="female">Homme</option>
                                                   </select>
                                                </td>
                                             </tr>
                                             <tr>
                                                <td class="field">Birthdate</td>
                                                <td>
                                                   <select class="form-control input-inline input-xs" name="day">
                                                      <option value="04" selected="">04</option>
                                                   </select>
                                                   
                                                   <select class="form-control input-inline input-xs" name="month">
                                                      <option value="11" selected="">11</option>
                                                   </select>
                                                   -
                                                   <select class="form-control input-inline input-xs" name="year">
                                                      <option value="1989" selected="">1989</option>
                                                   </select>
                                                   <input type="date" class="form-control input-inline input-xs" name="date">
                                                </td>
                                             </tr>
                                             <tr class="divider">
                                                <td colspan="2"></td>
                                             </tr>
                                             <tr class="highlight">
                                                <td class="field">&nbsp;</td>
                                                <td class="p-t-10 p-b-10">
                                                   <button type="submit" class="btn btn-primary width-150">Update</button>
                                                   <button type="submit" class="btn btn-white btn-white-without-border width-150 m-l-5">Cancel</button>
                                                </td>
                                             </tr>
                                          </tbody>
                                       </table>
                                    </div>
                                    <!-- end table -->
                                 </div>
                                 <!-- end #profile-about tab -->
                              </div>
                              <!-- end tab-content -->
                           </div>
                           <!-- end profile-content -->
                        </div>
                     </div>
                  </div>
               </div>
                        </div>
                  </div>
               </div>
         </div>
          <?php
          }
        

         if($action == 'photo' ){
         ?>

         <?php
            header("location:mes_photo.php");  
            
         }

         if($action == 'album' ){
            ?>
   
            <?php
         }
      }
      ?>













        </div>
      </div>
    </div>
  </div>
</body>

</html>







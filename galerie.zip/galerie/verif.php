<?php
ini_set("display_errors", "1");
error_reporting(E_ALL);
require_once("config.php");
$login = $_POST['login'];
$passw = $_POST['pw'];

    try {
       
        $conn = new PDO($dsn, $user, $pw);
        echo "connexion etablie....!";
        $requete = "SELECT * from utilisateur U JOIN admin A on (U.id_admin = A.id_admin)  where etat !='DISACTIVER' and(( U.login='$login' and U.mot_passe='$passw') or ( A.login='$login' and A.mot_passe='$passw') )";

        $resultat = $conn->query($requete);
       
        if ($resultat->rowCount()== 0) {
            header("location:index.php?msg=0");           
        } else {
            session_start();
            $_SESSION['login']=$login;
            //$_SESSION['user']=$
            header("location:Accueil.php");
            
        }
    } catch(PDOExeption $e) {
        die($e->getMessage());
    }
?>
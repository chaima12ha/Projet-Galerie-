<?php
  session_start();
  if(!isset($_SESSION['login']))
  {
    header("location:index.php?msg=1");
  }
  else{
  }

?>


	<title>Ajouter un album</title>
	<link rel="stylesheet" type="text/css" href="style.css">
  <link rel="stylesheet" type="text/css" href="style_input.css">  
  <link rel="stylesheet" type="text/css" href="src/style/style_title.css">  
 


	<div class="page">
	<h2 class="main-title">AJOUTER ALBUM</h2>
	<hr width="90%" color="#2196f3">
	<div class="container">

		<form action="ajouter_album.php" method="post">
			<label for="nom_album">Nom de l'album:</label>
			<input type="text" id="nom_album" name="nom_album" required>

			<label for="des_album">Description de l'album:</label>
			<textarea id="des_album" name="des_album"></textarea>

			<label for="tag_album">Tags de l'album:</label>
			<input type="text" id="tag_album" name="tag_album">

			<label for="etat_album">Public ou privé:</label>
			<select id="etat_album" name="etat_album">
				<option value="1">Public</option>
				<option value="0">Privé</option>
			</select>
			<input type="submit" value="Ajouter l'album">
		</form>
	</div>




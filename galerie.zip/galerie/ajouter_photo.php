<?php
session_start();
if(!isset($_SESSION['login']))
{
    header("location:index.php?msg=1");
}

ini_set("display_errors", "1");
error_reporting(E_ALL);

require_once("config.php");

try {
$login =$_SESSION['login'];
    $conn = new PDO($dsn, $user, $pw);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

if (isset($_POST["submit"])) {

    $id_album = $_POST["id_album"];
    $nom_photo = $_POST["nom_photo"];
    $des_photo = $_POST["des_photo"];
    $tag_photo = $_POST["tag_photo"];
    $etat_photo = $_POST["etat_photo"];
    $date_photo = date("Y/m/d");


    $file_name = $_FILES['photo']['name'];
    $file_tmp = $_FILES['photo']['tmp_name'];
    $file_size = $_FILES['photo']['size'];
    $file_error = $_FILES['photo']['error'];

    // Vérifier si le fichier est une image
    $file_type = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
    $allowed_types = array("jpg", "jpeg", "png", "gif");
    if (!in_array($file_type, $allowed_types)) {
        echo "Seules les images JPG, JPEG, PNG et GIF sont autorisées.";
        exit();
    }
    // Vérifier si le fichier n'a pas d'erreurs
    if ($file_error !== 0) {
        echo "Il y a eu une erreur lors du téléchargement de l'image.";
        exit();
    }

    // Vérifier la taille du fichier
    if ($file_size > 2097152) {
        echo "La taille de l'image doit être inférieure à 2 Mo.";
        exit();
    }

    // Générer un nom de fichier unique
    $file_name_new = uniqid('', true) . '.' . $file_type;

    // Enregistrer le fichier dans le répertoire "image"
    $file_path = 'src/source/photo/' . $file_name_new;
    if (!move_uploaded_file($file_tmp, $file_path)) {
        echo "Il y a eu une erreur lors de l'enregistrement de l'image.";
        exit();
    }

    $sql = "INSERT INTO photo (id_album, nom_photo, date_photo, des_photo, tag_photo, etat_photo, photo,stock_photo)
            VALUES ('$id_album', '$nom_photo', '$date_photo', '$des_photo', '$tag_photo', '$etat_photo', '$file_path', $file_size)";
    $resultat = $conn->query($sql);
        header("location:Galerie.php");
   /* $sql2 = "UPDATE utilisateur SET stock_util = ( SELECT COUNT(stock_photo)FROM photo F JOIN album A ON (F.id_album = A.id_album) JOIN utilisateur U ON (A.id_util = U.id_util) WHERE login = '$login')
    WHERE login = '$login' AND (stock_util + $file_size) <= 21474836480;
    ";
    $resultat2 = $conn->query($sql2);

    if ($resultat2 and $resultat) {
        echo "La photo a été ajoutée avec succès à la base de données.";

    } else {
        echo "Erreur: " ;
    }
    */
}

<?php
$user = "dsi2g1";
    $pw = "dsi2g1";
    $database = "galerie";
    $host = "localhost"; // ou "127.0.0.1"
    $dsn = "mysql:host=$host;dbname=$database";
<?php
session_start();
if (!isset($_SESSION['login'])) {
  header("location:index.php?msg=1");
  exit(); // Ajout de l'instruction exit pour arrêter l'exécution du script après la redirection
} else {
  ini_set("display_errors", "1");
  error_reporting(E_ALL);
  require_once("config.php");
}

try {
  $con = new PDO($dsn, $user, $pw);
  $requser = "SELECT * FROM rapport";
  $resuser = $con->query($requser);

  if ($resuser->rowCount() == 0) {
    header("location:form_photo.php");
    exit(); // Ajout de l'instruction exit pour arrêter l'exécution du script après la redirection
  }
} catch (PDOException $e) {
  die($e->getMessage());
}

if (isset($_GET['action'])){
   
  $action = $_GET['action'];
  
  if($action == 'disactiver' ){
    $util=(int)$_GET['id_util'];
    $req_update = "UPDATE utilisateur SET etat = 'DISACTIVER'  WHERE id_util = $util";
    $res_update = $con->query($req_update);
    header("location:admin.php");

  }
  if($action == 'activer' ){
    $util=(int)$_GET['id_util'];
    $req_update = "UPDATE utilisateur SET etat = 'ACTIVER'  WHERE id_util = $util";
    $res_update = $con->query($req_update);
    header("location:admin.php");

  }

}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet">
  <link href="user.css" rel="stylesheet">
  <link href="src/style/style_title.css" rel="stylesheet"> 
  <title>Document</title>
</head>
<body>
  <div class="page">
  <h2 class="main-title">liste des rapports</h2>
  <hr width="90%" color="#2196f3">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="main-box clearfix">
            <div class="table-responsive">
              <table class="table user-list">
                <thead>
                  <tr>
                    <th><span>Id rapport</span></th>
                    <th><span>Id utilisateur</span></th>

                    <th class="text-center"><span>Sujet</span></th>
                    <th>&nbsp;</th>
                  </tr>
                </thead>
                <tbody>
                  <?php
                  while ($rowuser = $resuser->fetch(PDO::FETCH_ASSOC)) {
                  ?>
                  <tr>
                  <td>
                      <span class="user-subhead"><?php echo $rowuser['id_rapport']; ?></span>
                    </td>
                    <td>
                      <span class="user-subhead"><?php echo $rowuser['id_util1']; ?></span>
                    </td>
                    <td class="text-center">
                      <span class="label label-default"><?php echo $rowuser['sujet'];?></span>
                    </td>

                  </tr>
                  <?php
                  }
                  ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</body>
</html>

<?php
  session_start();
  if(!isset($_SESSION['login']))
  {
    header("location:index.php?msg=1");
  }
  else{
    $login =$_SESSION['login'];
     ini_set("display_errors", "1");
      error_reporting(E_ALL);
      require_once("config.php");
      $conn = new PDO($dsn, $user, $pw);

      $requser = "select * from utilisateur  where login= '$login'";
      $resuser= $conn->query($requser);
      $rowuser = $resuser->fetch();
      $util1 = $rowuser['id_util'];
      $login1 =$rowuser['login'];
  }

  if (isset($_GET['action'])){
   
    $action = $_GET['action'];
    
      if($action == 'voter' ){

        $vote =$_POST['vote'];
       // echo $vote;
        $photo=(int)$_GET['id_photo'];

        $reqs = "SELECT * FROM `vote` WHERE (`id_util`=$util1) AND (`id_photo`=$photo)  ";
        $ress= $conn->query($reqs);
        
        if ($ress->rowCount() > 0) {
          $requ="update vote set vote = $vote where id_photo= $photo and id_util =$util1";
          $resu = $conn->query($requ);
            //echo("update ");
        }else{
          $reqi="insert into vote(id_util,id_photo,vote) values($util1,$photo,$vote)";
          $resi = $conn->query($reqi);
          //echo("insertion");
        }      
          // action = vote
      }
      if($action == 'supprimer' ){

        $photo=(int)$_GET['id_photo'];

        $req_delete = "DELETE  FROM favoris  WHERE   `id_photo`= $photo ";
        $res_delete = $conn->query($req_delete );
        if($res_delete){
          //echo("delete terminer <br>");
        }


          // action = spprimer
      }
      
      if($action == 'photo_profi' ){
        $photo=(int)$_GET['id_photo'];

        $req_photo = "SELECT photo FROM `photo` WHERE `id_photo`=$photo  ";
        $res_photo= $conn->query($req_photo);
        $row_photo = $res_photo->fetch();
        $file_path = $row_photo['photo'];

        $req_update="UPDATE utilisateur
        SET image_prof = '$file_path'
        WHERE login = '$login'  ";
        //echo  $req_update ;
        $res_update= $conn->query($req_update);
        $row_update = $res_update->fetch();
        
      }

  }


?>
<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Galerie</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
    integrity="sha512-34e/X5vzG8W5+ml4D4dtYmttlUnSmvSNpgWwUuOnr1C7+9eOYMxKmBfFWLAgIYVgOuTYvQHw7STI74bQ2Ngy9g=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
  <link rel="stylesheet" href="src/style/style_box_image.css" />
  <link rel="stylesheet" href="src/style/stylestar.css" />
  <link rel="stylesheet" href="src/style/style_modal.css" />
  <link rel="stylesheet" href="src/style/stylestar.css" />
  <link rel="stylesheet" href="src/style/style_auti.css">
  <link rel="stylesheet" href="src/style/style_title.css">

  
</head>


<body>
  <div class="page">
  <h2 class="main-title">favorite</h2>
  <hr width="90%" color="#2196f3">
  <div class="container">
  <?php

      $reqs = "SELECT * FROM utilisateur U JOIN favoris FA on (FA.id_util = U.id_util ) join photo F on(FA.id_photo = F.id_photo ) WHERE login= '$login'";

      $ress = $conn->query($reqs);

      if ($ress->rowCount()== 0) {
        echo("<h2 class='main-title2'> AUCUNE IMAGE DISPONIBLE </h2>"); 
      } 
  ?>
    <div class="box">
      <?php
          try { 

            
              $requete = "SELECT * FROM utilisateur U JOIN favoris FA on (FA.id_util = U.id_util ) join photo F on(FA.id_photo = F.id_photo ) WHERE login= '$login'";

              $resultat = $conn->query($requete);
            
              if ($resultat->rowCount()== 0) {
                // header("location:Galerie.php?");           
              } else {
              $x=0; 
                while ($row = $resultat->fetch()) {
              ?>
      <div class="container2">
      <div class="photo-box">
        <img src="<?php echo( $row['photo']);?>" alt="Photo" />
        <div class="buttons">

          <?php
              // vote selection
              $photo_vote = $row['id_photo'];
              $req_vote = "select avg(vote) as 'v' from vote  where  id_photo=$photo_vote ;";
              $res_vote= $conn->query($req_vote);
              $row_vote = $res_vote->fetch();
              $vote = $row_vote['v'];
              if($vote >0){
              $vote =number_format($vote, 1, ',');
              echo ('<button><span class="fa fa-star checked"> '.$vote.' </span></button>');
              }
              ?>






          <button class="vote" id="<?php echo("myBtn".$x); ?>" onclick="modal(
            <?php echo($x); ?>);">
            <i class="fa fa-thumbs-up"></i>voter
          </button>
          <?php echo'<div id="myModal'.$x.'" class="modal">'; ?>
          <div class="modal-content">
            <?php echo'<span class="close close'.$x.'">&times;</span>'; ?>
            <div class="rating">
              <?php echo('
                  <div class="stars stars'.$x.'">
                    <span class="star star'.$x.'" data-rating="1"></span>
                    <span class="star star'.$x.'" data-rating="2"></span>
                    <span class="star star'.$x.'" data-rating="3"></span>
                    <span class="star star'.$x.'" data-rating="4"></span>
                    <span class="star star'.$x.'" data-rating="5"></span>
                  </div>
                  '); ?>
            </div>

            <input type="hidden" name="rating" class="rating-value" id="rating_value<?php echo $x; ?>" />
            <form name="f" action="?action=voter&id_photo=<?php echo $row['id_photo']; ?>&id_util=<?php echo $row['id_util']; ?>" method="post" class="votestyle">
            <input type="text" name="vote" id="vote<?php echo $x; ?>" value="0" readonly>
              <!--<input type="text" name="vote" id="vote<?php //echo $x; ?>" value="0" readonly disabled >-->
              <div class="selected-rating selected_rating<?php echo $x; ?>"></div><br><br>
              <button class="starbuttan" id="starbuttan<?php echo $x; ?>">Voter</button>
            </form>
          </div>
        </div>
      </div>
      <div class="user-info">
        <img src="
        <?php 
          if(isset($row['image_prof'])){
              echo( $row['image_prof']);
            }
          else{
          echo" src/source/image/utilisateur.png"; } ?>
        "alt="User" />
        <span class="username">
          <?php echo($row['nom_util']);?>
        </span>
      </div>
      <div class="menu-info">
        <div id="<?php echo('mySidebar'.$x); ?>" class="sidebar">
          <a href="javascript:void(0)" class="closebtn" onclick="closeNav(<?php echo($x); ?>)">×</a>
          <?php
          $photo = $row['id_photo'];
          echo('<a href="?action=photo_profi&id_photo='.$photo.'" >defeni comme photo de profil</a>');
          echo('<a href="?action=supprimer&id_photo='.$photo.'" >supprimer de favorie</a>');

          ?>
        </div>

        <div id=" <?php echo('main'.$x); ?>">
          <button class="openbtn" onclick="openNav(<?php echo($x) ;?>)">☰</button>
        </div>
        <script src="src/controle/controle_auti.js"></script>
      </div>
    </div>
    </div>
    <?php
        $x=$x+1;
      }
    }
      } catch(PDOExeption $e) {
        die($e->getMessage());
    }
    ?>
  </div>
  </div>
</body>
<script src="src/controle/modal.js"></script>

</html>
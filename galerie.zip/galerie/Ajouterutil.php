<?php
  session_start();
  if(!isset($_SESSION['login']))
  {
    header("location:index.php?msg=1");
  }

?>
<?php
ini_set("display_errors", "1");
error_reporting(E_ALL);
require_once("config.php");
$admin =1;
$login = $_POST['login'];
$passw = $_POST['Motpasse'];
$name  = $_POST['Nom'];
$email = $_POST['Email'];

    try {
       
        $conn = new PDO($dsn, $user, $pw);
        echo "connexion etablie....!";
        $requete = "select * from utilisateur where login='$login' or mot_passe='$passw'";

        $resultat = $conn->query($requete);
       
        if ($resultat->rowCount()== 0) {
            $requete2 = " insert into utilisateur(id_admin,login,nom_util,email_util,mot_passe,etat) values ('$admin','$login','$name','$email','$passw','ACTIVE');";
            $resultat2 = $conn->query($requete2);
            session_start();
            $_SESSION['login']=$login;
            //$_SESSION['user']=$
            header("location:Accueil.php");
          
        } else {
            header("location:index.php?msg=0"); 
        }
    } catch(PDOExeption $e) {
        die($e->getMessage());
    }
?>
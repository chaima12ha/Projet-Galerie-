<?php
  session_start();
  if(!isset($_SESSION['login']))
  {
    header("location:index.php?msg=1");
  }
  else{
    $login = $_SESSION['login'];
  }
?>
<?php
    ini_set("display_errors", "1");
    error_reporting(E_ALL);
    require_once("config.php");



    try {
       
        $conn = new PDO($dsn, $user, $pw);
        echo "connexion etablie....!";
        $login=$_SESSION['login'];
        $requete = "select id_util from utilisateur where login='$login';";
        $resultat = $conn->query($requete); 
        $row = $resultat->fetch();
        
        $id_util=$row['id_util'];
        $nom_album = $_POST['nom_album'];
        $date_album = date('Y-m-d');
        $des_album = $_POST['des_album'];
        $tag_album = $_POST['tag_album'];
        $etat_album = $_POST['etat_album'];


        $requete2 = " insert into album(id_util, nom_album, date_album, des_album, tag_album, etat_album)
         values ('$id_util', '$nom_album', '$date_album', '$des_album','$tag_album',$etat_album);";
        $resultat2 = $conn->query($requete2);
        if($resultat2){
          header("location:Galerie.php");
        }

       
    } catch(PDOExeption $e) {
        die($e->getMessage());
    }

?>

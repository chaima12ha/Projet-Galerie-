
<!DOCTYPE html>
<html>

<head>
<meta property="og:image" content="src/source/image/royale.png">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="src/style/style.css">
    <title>Galerie </title>
</head>

<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <a class="logo"><img src="src/source/image/royale.png" alt=""> <span> Galerie Royale</span></a>
            <div class="main_nav">
                <form action="verif.php" method="post" onclick="verifi()">
                    <input type="text" name="login" placeholder="mot d'utilisation" title="mot d'utilisation" required>
                    <input type="password" name="pw" placeholder="Mot de passe" title="mot de passe" required>
                    <button>se connecter</button>
                    <?php
                    if (isset($_GET['msg'])) {
                        $msg=$_GET['msg'];
                        if ($msg==0) {
                            echo "Login ou mot de passe incorrect....";
                        }
                        if ($msg==1) {
                            echo "Vous devez vous connecter d'abord";
                        }
                        if ($msg==2) {
                            echo "Vous avez ete deconnecte...";    }    
                    }
                    ?>
                </form>
            </div>
        </div>
    </header>
    <!-- Fin Header -->
    <!-- Landing -->
    <div class="landing">
        <div class="container">
            <div class="login">
                <h1 title="C’est rapide et facile, de créer votre compte pour inscrire sur MHBM">s'inscrire </h1>
                <hr>
                <form action="Ajouterutil.php" onclick="verifi()" method="post">
                    <div class="p">
                        <input type="text" id="Nom" name="Nom" placeholder="Nom" pattern="[A-Za-z]{3,15}"
                            title="Nom " required >                    
                        <input type="text" id="Email" name="Email" placeholder="Adress e-mail "
                            pattern="[a-z0-9._%+-@]{8,30}" title="Adresse e-mail inferieure a 8 caracteur" class="email" required>
                        <br>
                        <input type="text" id="login" name="login" placeholder="mot d'utilisation "
                            pattern="[A-Za-z0-9]{8,30}" title="mot d'utilisation est inferieure a 8 caracteur " required>
                        <br>
                        <input type="password" id="Motpasse" name="Motpasse" placeholder="Nouveau mot de passe"
                            pattern="[a-z0-9._%+-@]{8,15}" title="Nouveau mot de passe" required>
                        <input type="password" id="Cmotpasse" name="Cmotpasse" placeholder="Confirmer mot de passe "
                            pattern="[a-z0-9._-]{8,15}" title="Confirmer mot de passe" required>
                        <br>
                    </div>
                    <hr>
                    <p title="Acceptez nos Conditions">En cliquant sur S’inscrire, vous acceptez nos Conditions
                        générales,
                        notre Politique de confidentialité et notre Politique d’utilisation des cookies. Vous recevrez
                        peut-être des notifications par texto de notre part et vous pouvez à
                        tout moment vous désabonner.
                    </p>
                    <button title="Inscrire">S'inscrire</button>
                </form>
            </div>
            <div class="imagelanding ">
                <img src="src/source/image/1.png" alt="image ">
            </div>
        </div>
    </div>
    <!-- Fin Landing -->
    <footer class="footer ">
        <div class="container ">
            <a class="logo "><img src="src/source/image/royale.png" alt=""> <span> Galerie Royale</span>© 2023</a>
        </div>
    </footer>
</body>
<script language="javascript" src="src/controle/controle.js">


</script>

</html>
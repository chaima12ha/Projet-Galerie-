<?php
  session_start();
  if(!isset($_SESSION['login']))
  {
    header("location:index.php?msg=1");
  }
  else{
    $login =$_SESSION['login'];
     ini_set("display_errors", "1");
      error_reporting(E_ALL);
      require_once("config.php");
      $conn = new PDO($dsn, $user, $pw);

      $requser = "select * from utilisateur  where login= '$login'";
      $resuser= $conn->query($requser);
      $rowuser = $resuser->fetch();
      $util1 = $rowuser['id_util'];
      $login1 =$rowuser['login'];
  }

  if (isset($_GET['action'])){
   
    $action = $_GET['action'];
    
      if($action == 'supprimer' ){
        $photo=(int)$_GET['id_photo'];
  
          $req_delete = "DELETE  FROM corbeille  WHERE   `id_photo`= $photo ";
          $res_delete = $conn->query($req_delete );
          if($res_delete){
            //echo("delete terminer <br>");
          }
  
  
            // action = spprimer
      }
      if($action == 'restsaurer' ){
        $photo=(int)$_GET['id_photo'];

        $req_photo = "SELECT * FROM `corbeille` WHERE   (`id_photo`=$photo)  ";
        $res_photo= $conn->query($req_photo);
        $row_photo = $res_photo->fetch();

        $id_album = $row_photo['id_album'];
        $id_photo = $row_photo['id_photo'];
        $nom_photo = $row_photo['nom_photo'];
        $des_photo = $row_photo['des_photo'];
        $tag_photo = $row_photo['tag_photo'];
        $etat_photo = $row_photo['etat_photo'];
        $date_photo = $row_photo['date_photo'];
        $file_path = $row_photo['photo'];
        $file_size = $row_photo['stock_photo'];

        if ($res_photo->rowCount() > 0) {
            $req_corbeille = "INSERT INTO photo (id_photo, id_album, nom_photo, date_photo, des_photo, tag_photo, etat_photo, photo,stock_photo)
            VALUES ( '$id_photo', '$id_album', '$nom_photo', '$date_photo', '$des_photo', '$tag_photo', '$etat_photo', '$file_path', $file_size)";
            $res_corbeille = $conn->query($req_corbeille);
            if($res_corbeille){
              //echo ("insertion album <br>"); 
                $req_delete = "DELETE  FROM corbeille  WHERE   `id_photo`= $photo ";
                $res_delete = $conn->query($req_delete );
                if($res_delete){
               // echo("delete terminer <br>");
               header("location:Galerie.php");
              }
            }
        }
        //action = retsaurer
      }
      
  }


?>
<!DOCTYPE html>
<html lang="fr">

<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Galerie</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"
    integrity="sha512-34e/X5vzG8W5+ml4D4dtYmttlUnSmvSNpgWwUuOnr1C7+9eOYMxKmBfFWLAgIYVgOuTYvQHw7STI74bQ2Ngy9g=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
  <link rel="stylesheet" href="src/style/style_box_image.css" />
  <link rel="stylesheet" href="src/style/stylestar.css" />
  <link rel="stylesheet" href="src/style/style_modal.css" />
  <link rel="stylesheet" href="src/style/stylestar.css" />
  <link rel="stylesheet" href="src/style/style_auti.css">
  <link rel="stylesheet" href="src/style/style_title.css">

  
</head>


<body>
  <div class="page">
  <h2 class="main-title">corbeille</h2>
  <hr width="90%" color="#2196f3">
  <div class="container">

      <?php

              $requete = "SELECT * FROM corbeille C JOIN album A ON (C.id_album = A.id_album ) JOIN utilisateur U
              ON (A.id_util = U.id_util ) WHERE login= '$login' ORDER BY date_photo DESC";

              $resultat = $conn->query($requete);

              if ($resultat->rowCount()== 0) {
                echo("<h2 class='main-title2'>lA  CORBEILLE  EST  VIDE </h2>"); 
              } 
                ?>
              <div class="box">
              <?php
              try { 
              $x=0; 
                while ($row = $resultat->fetch()) {
              ?>
      <div class="container2">
      <div class="photo-box">
        <img src="<?php echo( $row['photo']);?>" alt="Photo" />

      <div class="user-info">
        <img src="
        <?php 
          if(isset($row['image_prof'])){
              echo( $row['image_prof']);
            }
          else{
          echo" src/source/image/utilisateur.png"; } ?>
        "alt="User" />
        <span class="username">
          <?php echo($row['nom_util']);?>
        </span>
      </div>
      <div class="menu-info">
        <div id="<?php echo('mySidebar'.$x); ?>" class="sidebar">
          <a href="javascript:void(0)" class="closebtn" onclick="closeNav(<?php echo($x); ?>)">×</a>
          <?php
          $photo = $row['id_photo'];
          echo('<a href="?action=supprimer&id_photo='.$photo.'" >supprimer de corbeille</a>');
          echo('<a href="?action=restsaurer&id_photo='.$photo.'" >restoure la photo</a>');

          ?>
          
        </div>

        <div id=" <?php echo('main'.$x); ?>">
          <button class="openbtn" onclick="openNav(<?php echo($x) ;?>)">☰</button>
        </div>
        <script src="src/controle/controle_auti.js"></script>
      </div>
    </div>
    </div>
    <?php
        $x=$x+1;
      }
    
      } catch(PDOExeption $e) {
        die($e->getMessage());
    }
    ?>
  </div>
  </div>
</body>
<script src="src/controle/modal.js"></script>

</html>